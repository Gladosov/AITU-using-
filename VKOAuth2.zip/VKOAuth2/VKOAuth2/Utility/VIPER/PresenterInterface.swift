protocol PresenterInterface: class {
}

extension PresenterInterface {
}
