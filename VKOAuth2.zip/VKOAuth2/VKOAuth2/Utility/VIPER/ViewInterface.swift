protocol ViewInterface: class {
}

extension ViewInterface {
}
