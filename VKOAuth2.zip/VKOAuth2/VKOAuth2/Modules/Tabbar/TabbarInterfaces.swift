//
// TabbarInterfaces.swift
// VKOAuth2
//
// Created by Admin on 24.02.2021.
//

import UIKit

protocol TabbarWireframeInterface: WireframeInterface {
}

protocol TabbarViewInterface: ViewInterface {
}

protocol TabbarPresenterInterface: PresenterInterface {
}

protocol TabbarInteractorInterface: InteractorInterface {
}
