//
// LoginInteracotr.swift
// VKOAuth2
//
// Created by Admin on 24.02.2021.
//

import Foundation

final class LoginInteractor {
}

// MARK: - Extensions -

extension LoginInteractor: LoginInteractorInterface {
}
